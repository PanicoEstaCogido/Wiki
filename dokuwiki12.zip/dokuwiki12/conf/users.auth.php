# users.auth.php
# <?php exit()?>
# Don't modify the lines above
#
# Userfile
#
# Format:
#
# login:passwordhash:Real Name:email:groups,comma,separated


administrador:$1$MRScrCQy$bAUnI.Herb7k4UjKoIu0z1:administrador:20dlagopaz01@gmail.com:admin,user
