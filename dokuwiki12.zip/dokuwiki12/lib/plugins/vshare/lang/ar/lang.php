<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Nitaky <info@nitaky.com>
 */
$lang['js']['button']          = 'أدرج الفيديو من خلال مواقع تشارك الفيديوهات';
$lang['js']['prompt']          = 'من فضلك قم بوضع رابط الفيديو كاملا هنا';
$lang['js']['notfound']        = 'عذرا، الرابط هذا لم يتم قبوله.
نرجو منك العودة إلى الشروحات التي تبين الطريقة المثلى لإدراج الروابط بالشكل الصحيح يدويا.';
