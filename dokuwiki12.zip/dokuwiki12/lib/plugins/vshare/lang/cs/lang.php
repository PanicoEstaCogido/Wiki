<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Jakub Duchek <jakduch@jakduch.cz>
 */
$lang['js']['prompt']          = 'Vložte prosím celý odkaz na stránku videa zde:';
