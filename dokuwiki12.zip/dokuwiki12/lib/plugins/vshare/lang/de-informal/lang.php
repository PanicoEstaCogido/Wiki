<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author F. Mueller-Donath <j.felix@mueller-donath.de>
 */
$lang['js']['button']          = 'Video von Videoplattformen einfügen';
$lang['js']['prompt']          = 'Bitte füge hier die komplette URL zur Videoseite ein:';
$lang['js']['notfound']        = 'Die URL wurde leider nicht erkannt.
Bitte lies in der Dokumentation nach wie du die korrekte Syntax für dieses Video manuell eingeben kannst.';
