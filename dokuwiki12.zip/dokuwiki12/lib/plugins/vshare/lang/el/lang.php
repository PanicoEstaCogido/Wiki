<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Katerina Katapodi <extragold1234@hotmail.com>
 */
$lang['js']['button']          = 'Εισάγετε βίντεο από τις ιστοσελίδες προβολής βίντεο';
$lang['js']['prompt']          = 'Παρακαλώ επικολλήστε ολόκληρο το URL στην εικόνα βιντεο εδώ:';
$lang['js']['notfound']        = 'Συγγνώμη αυτή η σελίδα δεν αναγνωρίστηκε. Παρακαλώ αναφερθείτε στα έγγραφα του πώς να διορθώσετε τη σύνταξη χειροκίνητα.';
