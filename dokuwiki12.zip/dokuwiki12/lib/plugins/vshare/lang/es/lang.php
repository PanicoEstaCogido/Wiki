<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Domingo Redal <docxml@gmail.com>
 */
$lang['js']['button']          = 'Insertar vídeo desde un sitio dedicado a compartir vídeos';
$lang['js']['prompt']          = 'Pegue la dirección URL completa de la página del vídeo aquí:';
$lang['js']['notfound']        = 'Lo sentimos, la dirección URL no fue reconocida.
Consulte la documentación sobre cómo insertar manualmente la sintaxis correcta.';
