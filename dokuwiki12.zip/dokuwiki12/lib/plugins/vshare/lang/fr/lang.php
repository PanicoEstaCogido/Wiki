<?php
/**
 * French language file for vshare plugin
 *
 * @author Fabrice DEJAIGHER <fabrice@chtiland.com>
 */

$lang['js']['button'] = 'Insère une vidéo depuis des sites de partage vidéo';
$lang['js']['prompt'] = 'Copiez/collez le lien complet de la page contenant la vidéo ici :';
$lang['js']['notfound'] = "Désolé, cette URL n'a pas été reconnue. Consultez la documentation sur la syntaxe pour insérer une vidéo manuellement.";