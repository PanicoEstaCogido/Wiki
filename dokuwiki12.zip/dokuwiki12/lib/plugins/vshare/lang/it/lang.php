<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Paolo Russo <paolo@crowddreaming.academy>
 */
$lang['js']['button']          = 'Inserisci il video dal sito di video sharing';
$lang['js']['prompt']          = 'Per favore, incolla qui la URL completa della pagina del video:';
$lang['js']['notfound']        = 'Spiacenti, questa URL non è stata riconosciuta.
Per favore, controlla la documentazione su come inserire a mano la sintassi corretta.';
