<?php
/**
* japanese language file
*
* @license GPL 2 (http://www.gnu.org/licenses/gpl.html)
*/

$lang['js']['button'] = '動画共有サイトの動画を挿入';
$lang['js']['prompt'] = 'ここに動画ページへの完全な URL を貼り付けて下さい：';
$lang['js']['notfound'] = "申し訳ないですが、この URL が認識されません。\n手動で正しい構文を挿入する方法をマニュアルで確認して下さい。";
