<?php
/**
 * Korean language file for vshare plugin
 *
 * @author Myeongjin <aranet100@gmail.com>
 */

$lang['js']['button'] = '동영상 공유 사이트에서 동영상 넣기';
$lang['js']['prompt'] = '여기에 동영상 페이지의 전체 URL을 붙여넣으세요:';
$lang['js']['notfound'] = "죄송하지만 이 URL을 인식할 수 없습니다.\n수동으로 올바른 문법을 넣는 방법에 대해서는 설명문서를 참조하세요.";
