<?php

/**
 * Dutch language file for vshare plugin.
 *
 * @author Mark C. Prins <mprins@users.sf.net>
 */
$lang['js']['button'] = 'Voeg een video van een video-delen website in';
$lang['js']['prompt'] = 'Plak hier de volledige URL voor de video pagina:';
$lang['js']['notfound'] = "Sorry, deze URL werd niet herkend.\nRaadpleeg de documentatie over de juiste syntax om een URL handmatig in te voegen.";
