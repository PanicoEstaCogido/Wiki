<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Karstein Kvistad <spamme.post@gmail.com>
 */
$lang['js']['button']          = 'Sett inn video fra videodelingstjenester';
$lang['js']['prompt']          = 'Lim inn hele web-lenken til videodelingssiden her:';
$lang['js']['notfound']        = 'Beklager, denne lenken ble ikke gjenkjent.
Vær vennlig å sjekk dokumentasjonen for hvordan å sette inn lenke med riktig syntaks.';
