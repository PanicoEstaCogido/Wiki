<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Bartek S <sadupl@gmail.com>
 */
$lang['js']['button']          = 'Wstaw wideo z witryn udostępniających wideo';
$lang['js']['prompt']          = 'Wklej tutaj pełny adres URL do wideo:';
$lang['js']['notfound']        = 'Przepraszamy, ten URL nie został rozpoznany.
Proszę zapoznaj się z dokumentacją jak ręcznie wstawić poprawną składnię.';
