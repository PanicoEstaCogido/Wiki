<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Thiago Lima <thiagolimaes@gmail.com>
 */
$lang['js']['button']          = 'Insira o vídeo um um site de compartilhamento de vídeos';
$lang['js']['prompt']          = 'Por favor, cole aqui a URL completa da página do vídeo:';
$lang['js']['notfound']        = 'Desculpe, a URL não foi reconhecida.
Visite a documentação para saber com adicionar o vídeo com a sintaxe correta.';
