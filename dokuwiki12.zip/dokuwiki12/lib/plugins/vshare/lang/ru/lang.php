<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Yuriy Skalko <yuriy.skalko@gmail.com>
 */
$lang['js']['button']          = 'Вставить видео с сайтов обмена видео ';
$lang['js']['prompt']          = 'Пожалуйста, вставьте полный URL на страницу видео:';
$lang['js']['notfound']        = 'Извините, этот URL не распознается. Пожалуйста, обратитесь к документации о том, как использовать правильный синтаксис .';
