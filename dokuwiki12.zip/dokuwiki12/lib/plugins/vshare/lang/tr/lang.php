<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Hakan <hakandursun2009@gmail.com>
 */
$lang['js']['button']          = 'Video paylaşım sitelerinden video ekle';
$lang['js']['prompt']          = 'Lütfen tam URL\'yi video sayfasına yapıştırın:';
$lang['js']['notfound']        = 'Üzgünüz, bu URL tanınmadı.
Lütfen doğru sözdizimini manuel olarak nasıl ekleyeceğinize bakın.';
