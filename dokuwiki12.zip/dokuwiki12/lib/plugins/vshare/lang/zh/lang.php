<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Blog.bhyoo.xyz <rowing@bhyoo.xyz>
 */
$lang['js']['button']          = '从视频分享网站插入视频';
$lang['js']['prompt']          = '请在这里粘贴视频页面的完整链接：';
$lang['js']['notfound']        = '抱歉，这个网址无法识别。
请参阅有关如何手动插入正确语法的文档。';
